from django.core.urlresolvers import reverse
from django_extensions.db.fields import AutoSlugField
from django.db.models import *
from django.conf import settings
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth import get_user_model
from django.contrib.auth import models as auth_models
from django.db import models as models
from django_extensions.db import fields as extension_fields


class Anolectivo(models.Model):

    # Fields
    id_anolectivo = AutoField(primary_key=True)
    nombre = CharField(max_length=100)
    estado = BooleanField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('appjardin_anolectivo_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('appjardin_anolectivo_update', args=(self.pk,))


class Estudiante(models.Model):

    # Fields
    id_estudiante = AutoField(primary_key=True)
    tipo_sangre = CharField(max_length=10)
    alergias = CharField(max_length=300)
    id_secretaria = IntegerField()

    # Relationship Fields
    id = ForeignKey(
        models.DO_NOTHING, db_column='id', on_delete=models.CASCADE
    )

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('appjardin_estudiante_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('appjardin_estudiante_update', args=(self.pk,))


class Matricula(models.Model):

    # Fields
    id_matricula = AutoField(primary_key=True)
    costo = FloatField()
    fecha = DateTimeField()

    # Relationship Fields
    id_preinscripcion = ForeignKey(
        models.DO_NOTHING, db_column='id_preinscripcion', on_delete=models.CASCADE
    )
    id_paralelo = ForeignKey(
        models.DO_NOTHING, db_column='id_paralelo', on_delete=models.CASCADE
    )

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('appjardin_matricula_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('appjardin_matricula_update', args=(self.pk,))


class Nivel(models.Model):

    # Fields
    id_nivel = AutoField(primary_key=True)
    nombre = CharField(max_length=50)

    # Relationship Fields
    id_anolectivo = ForeignKey(
        models.DO_NOTHING, db_column='id_anolectivo', on_delete=models.CASCADE
    )

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('appjardin_nivel_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('appjardin_nivel_update', args=(self.pk,))


class Paralelo(models.Model):

    # Fields
    id_paralelo = IntegerField(primary_key=True)

    # Relationship Fields
    id_profesor = ForeignKey(
        models.DO_NOTHING, db_column='id_profesor', on_delete=models.CASCADE
    )

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('appjardin_paralelo_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('appjardin_paralelo_update', args=(self.pk,))


class Pension(models.Model):

    # Fields
    id_pension = AutoField(primary_key=True)
    costo = FloatField()

    # Relationship Fields
    id_matricula = ForeignKey(
        models.DO_NOTHING, db_column='id_matricula', on_delete=models.CASCADE
    )

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('appjardin_pension_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('appjardin_pension_update', args=(self.pk,))


class Preinscripcion(models.Model):

    # Fields
    id_preinscripcion = AutoField(primary_key=True)
    fecha = DateTimeField()

    # Relationship Fields
    id_estudiante = ForeignKey(
        models.DO_NOTHING, db_column='id_estudiante', on_delete=models.CASCADE
    )
    id_representante = ForeignKey(
        models.DO_NOTHING, db_column='id_representante', on_delete=models.CASCADE
    )
    id_nivel = ForeignKey(
        models.DO_NOTHING, db_column='id_nivel', on_delete=models.CASCADE
    )
    id_secretaria = ForeignKey(
        models.DO_NOTHING, db_column='id_secretaria', on_delete=models.CASCADE
    )

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('appjardin_preinscripcion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('appjardin_preinscripcion_update', args=(self.pk,))


class Profesor(models.Model):

    # Fields
    id_profesor = AutoField(primary_key=True)
    titulo_profesor = CharField(max_length=50)
    celular = CharField(max_length=25)
    estado_civil = CharField(max_length=10)

    # Relationship Fields
    id = ForeignKey(
        models.DO_NOTHING, db_column='id', on_delete=models.CASCADE
    )

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('appjardin_profesor_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('appjardin_profesor_update', args=(self.pk,))


class Representante(models.Model):

    # Fields
    id_representante = AutoField(primary_key=True)
    celular = CharField(max_length=25)
    correo = CharField(max_length=150)

    # Relationship Fields
    id = ForeignKey(
        models.DO_NOTHING, db_column='id', on_delete=models.CASCADE
    )

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('appjardin_representante_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('appjardin_representante_update', args=(self.pk,))


class Representanteestudiante(models.Model):

    # Fields
    id_representanteestudiante = AutoField(primary_key=True)

    # Relationship Fields
    id_estudiante = ForeignKey(
        models.DO_NOTHING, db_column='id_estudiante', on_delete=models.CASCADE
    )
    id_representante = ForeignKey(
        models.DO_NOTHING, db_column='id_representante', on_delete=models.CASCADE
    )

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('appjardin_representanteestudiante_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('appjardin_representanteestudiante_update', args=(self.pk,))


class Rol(models.Model):

    # Fields
    id_rol = AutoField(primary_key=True)
    estudiante = BooleanField()
    profesor = BooleanField()

    # Relationship Fields
    id = ForeignKey(
        models.DO_NOTHING, db_column='id', on_delete=models.CASCADE
    )

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('appjardin_rol_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('appjardin_rol_update', args=(self.pk,))


class Secretaria(models.Model):

    # Fields
    id_secretaria = AutoField(primary_key=True)
    fecha_ingreso = DateField()

    # Relationship Fields
    id = ForeignKey(
        models.DO_NOTHING, db_column='id', on_delete=models.CASCADE
    )

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('appjardin_secretaria_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('appjardin_secretaria_update', args=(self.pk,))


