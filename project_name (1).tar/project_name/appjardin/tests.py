import unittest
from django.core.urlresolvers import reverse
from django.test import Client
from .models import Anolectivo, Estudiante, Matricula, Nivel, Paralelo, Pension, Preinscripcion, Profesor, Representante, Representanteestudiante, Rol, Secretaria
from django.contrib.auth.models import User
from django.contrib.auth.models import Group
from django.contrib.contenttypes.models import ContentType


def create_django_contrib_auth_models_user(**kwargs):
    defaults = {}
    defaults["username"] = "username"
    defaults["email"] = "username@tempurl.com"
    defaults.update(**kwargs)
    return User.objects.create(**defaults)


def create_django_contrib_auth_models_group(**kwargs):
    defaults = {}
    defaults["name"] = "group"
    defaults.update(**kwargs)
    return Group.objects.create(**defaults)


def create_django_contrib_contenttypes_models_contenttype(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    return ContentType.objects.create(**defaults)


def create_anolectivo(**kwargs):
    defaults = {}
    defaults["id_anolectivo"] = "id_anolectivo"
    defaults["nombre"] = "nombre"
    defaults["estado"] = "estado"
    defaults.update(**kwargs)
    return Anolectivo.objects.create(**defaults)


def create_estudiante(**kwargs):
    defaults = {}
    defaults["id_estudiante"] = "id_estudiante"
    defaults["tipo_sangre"] = "tipo_sangre"
    defaults["alergias"] = "alergias"
    defaults["id_secretaria"] = "id_secretaria"
    defaults.update(**kwargs)
    if "id" not in defaults:
        defaults["id"] = create_authuser()
    return Estudiante.objects.create(**defaults)


def create_matricula(**kwargs):
    defaults = {}
    defaults["id_matricula"] = "id_matricula"
    defaults["costo"] = "costo"
    defaults["fecha"] = "fecha"
    defaults.update(**kwargs)
    if "id_preinscripcion" not in defaults:
        defaults["id_preinscripcion"] = create_'preinscripcion'()
    if "id_paralelo" not in defaults:
        defaults["id_paralelo"] = create_'paralelo'()
    return Matricula.objects.create(**defaults)


def create_nivel(**kwargs):
    defaults = {}
    defaults["id_nivel"] = "id_nivel"
    defaults["nombre"] = "nombre"
    defaults.update(**kwargs)
    if "id_anolectivo" not in defaults:
        defaults["id_anolectivo"] = create_anolectivo()
    return Nivel.objects.create(**defaults)


def create_paralelo(**kwargs):
    defaults = {}
    defaults["id_paralelo"] = "id_paralelo"
    defaults.update(**kwargs)
    if "id_profesor" not in defaults:
        defaults["id_profesor"] = create_'profesor'()
    return Paralelo.objects.create(**defaults)


def create_pension(**kwargs):
    defaults = {}
    defaults["id_pension"] = "id_pension"
    defaults["costo"] = "costo"
    defaults.update(**kwargs)
    if "id_matricula" not in defaults:
        defaults["id_matricula"] = create_matricula()
    return Pension.objects.create(**defaults)


def create_preinscripcion(**kwargs):
    defaults = {}
    defaults["id_preinscripcion"] = "id_preinscripcion"
    defaults["fecha"] = "fecha"
    defaults.update(**kwargs)
    if "id_estudiante" not in defaults:
        defaults["id_estudiante"] = create_estudiante()
    if "id_representante" not in defaults:
        defaults["id_representante"] = create_'representante'()
    if "id_nivel" not in defaults:
        defaults["id_nivel"] = create_nivel()
    if "id_secretaria" not in defaults:
        defaults["id_secretaria"] = create_'secretaria'()
    return Preinscripcion.objects.create(**defaults)


def create_profesor(**kwargs):
    defaults = {}
    defaults["id_profesor"] = "id_profesor"
    defaults["titulo_profesor"] = "titulo_profesor"
    defaults["celular"] = "celular"
    defaults["estado_civil"] = "estado_civil"
    defaults.update(**kwargs)
    if "id" not in defaults:
        defaults["id"] = create_authuser()
    return Profesor.objects.create(**defaults)


def create_representante(**kwargs):
    defaults = {}
    defaults["id_representante"] = "id_representante"
    defaults["celular"] = "celular"
    defaults["correo"] = "correo"
    defaults.update(**kwargs)
    if "id" not in defaults:
        defaults["id"] = create_authuser()
    return Representante.objects.create(**defaults)


def create_representanteestudiante(**kwargs):
    defaults = {}
    defaults["id_representanteestudiante"] = "id_representanteestudiante"
    defaults.update(**kwargs)
    if "id_estudiante" not in defaults:
        defaults["id_estudiante"] = create_estudiante()
    if "id_representante" not in defaults:
        defaults["id_representante"] = create_representante()
    return Representanteestudiante.objects.create(**defaults)


def create_rol(**kwargs):
    defaults = {}
    defaults["id_rol"] = "id_rol"
    defaults["estudiante"] = "estudiante"
    defaults["profesor"] = "profesor"
    defaults.update(**kwargs)
    if "id" not in defaults:
        defaults["id"] = create_authuser()
    return Rol.objects.create(**defaults)


def create_secretaria(**kwargs):
    defaults = {}
    defaults["id_secretaria"] = "id_secretaria"
    defaults["fecha_ingreso"] = "fecha_ingreso"
    defaults.update(**kwargs)
    if "id" not in defaults:
        defaults["id"] = create_authuser()
    return Secretaria.objects.create(**defaults)


class AnolectivoViewTest(unittest.TestCase):
    '''
    Tests for Anolectivo
    '''
    def setUp(self):
        self.client = Client()

    def test_list_anolectivo(self):
        url = reverse('appjardin_anolectivo_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_anolectivo(self):
        url = reverse('appjardin_anolectivo_create')
        data = {
            "id_anolectivo": "id_anolectivo",
            "nombre": "nombre",
            "estado": "estado",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_anolectivo(self):
        anolectivo = create_anolectivo()
        url = reverse('appjardin_anolectivo_detail', args=[anolectivo.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_anolectivo(self):
        anolectivo = create_anolectivo()
        data = {
            "id_anolectivo": "id_anolectivo",
            "nombre": "nombre",
            "estado": "estado",
        }
        url = reverse('appjardin_anolectivo_update', args=[anolectivo.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class EstudianteViewTest(unittest.TestCase):
    '''
    Tests for Estudiante
    '''
    def setUp(self):
        self.client = Client()

    def test_list_estudiante(self):
        url = reverse('appjardin_estudiante_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_estudiante(self):
        url = reverse('appjardin_estudiante_create')
        data = {
            "id_estudiante": "id_estudiante",
            "tipo_sangre": "tipo_sangre",
            "alergias": "alergias",
            "id_secretaria": "id_secretaria",
            "id": create_authuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_estudiante(self):
        estudiante = create_estudiante()
        url = reverse('appjardin_estudiante_detail', args=[estudiante.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_estudiante(self):
        estudiante = create_estudiante()
        data = {
            "id_estudiante": "id_estudiante",
            "tipo_sangre": "tipo_sangre",
            "alergias": "alergias",
            "id_secretaria": "id_secretaria",
            "id": create_authuser().pk,
        }
        url = reverse('appjardin_estudiante_update', args=[estudiante.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class MatriculaViewTest(unittest.TestCase):
    '''
    Tests for Matricula
    '''
    def setUp(self):
        self.client = Client()

    def test_list_matricula(self):
        url = reverse('appjardin_matricula_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_matricula(self):
        url = reverse('appjardin_matricula_create')
        data = {
            "id_matricula": "id_matricula",
            "costo": "costo",
            "fecha": "fecha",
            "id_preinscripcion": create_'preinscripcion'().pk,
            "id_paralelo": create_'paralelo'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_matricula(self):
        matricula = create_matricula()
        url = reverse('appjardin_matricula_detail', args=[matricula.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_matricula(self):
        matricula = create_matricula()
        data = {
            "id_matricula": "id_matricula",
            "costo": "costo",
            "fecha": "fecha",
            "id_preinscripcion": create_'preinscripcion'().pk,
            "id_paralelo": create_'paralelo'().pk,
        }
        url = reverse('appjardin_matricula_update', args=[matricula.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class NivelViewTest(unittest.TestCase):
    '''
    Tests for Nivel
    '''
    def setUp(self):
        self.client = Client()

    def test_list_nivel(self):
        url = reverse('appjardin_nivel_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_nivel(self):
        url = reverse('appjardin_nivel_create')
        data = {
            "id_nivel": "id_nivel",
            "nombre": "nombre",
            "id_anolectivo": create_anolectivo().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_nivel(self):
        nivel = create_nivel()
        url = reverse('appjardin_nivel_detail', args=[nivel.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_nivel(self):
        nivel = create_nivel()
        data = {
            "id_nivel": "id_nivel",
            "nombre": "nombre",
            "id_anolectivo": create_anolectivo().pk,
        }
        url = reverse('appjardin_nivel_update', args=[nivel.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class ParaleloViewTest(unittest.TestCase):
    '''
    Tests for Paralelo
    '''
    def setUp(self):
        self.client = Client()

    def test_list_paralelo(self):
        url = reverse('appjardin_paralelo_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_paralelo(self):
        url = reverse('appjardin_paralelo_create')
        data = {
            "id_paralelo": "id_paralelo",
            "id_profesor": create_'profesor'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_paralelo(self):
        paralelo = create_paralelo()
        url = reverse('appjardin_paralelo_detail', args=[paralelo.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_paralelo(self):
        paralelo = create_paralelo()
        data = {
            "id_paralelo": "id_paralelo",
            "id_profesor": create_'profesor'().pk,
        }
        url = reverse('appjardin_paralelo_update', args=[paralelo.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PensionViewTest(unittest.TestCase):
    '''
    Tests for Pension
    '''
    def setUp(self):
        self.client = Client()

    def test_list_pension(self):
        url = reverse('appjardin_pension_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_pension(self):
        url = reverse('appjardin_pension_create')
        data = {
            "id_pension": "id_pension",
            "costo": "costo",
            "id_matricula": create_matricula().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_pension(self):
        pension = create_pension()
        url = reverse('appjardin_pension_detail', args=[pension.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_pension(self):
        pension = create_pension()
        data = {
            "id_pension": "id_pension",
            "costo": "costo",
            "id_matricula": create_matricula().pk,
        }
        url = reverse('appjardin_pension_update', args=[pension.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PreinscripcionViewTest(unittest.TestCase):
    '''
    Tests for Preinscripcion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_preinscripcion(self):
        url = reverse('appjardin_preinscripcion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_preinscripcion(self):
        url = reverse('appjardin_preinscripcion_create')
        data = {
            "id_preinscripcion": "id_preinscripcion",
            "fecha": "fecha",
            "id_estudiante": create_estudiante().pk,
            "id_representante": create_'representante'().pk,
            "id_nivel": create_nivel().pk,
            "id_secretaria": create_'secretaria'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_preinscripcion(self):
        preinscripcion = create_preinscripcion()
        url = reverse('appjardin_preinscripcion_detail', args=[preinscripcion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_preinscripcion(self):
        preinscripcion = create_preinscripcion()
        data = {
            "id_preinscripcion": "id_preinscripcion",
            "fecha": "fecha",
            "id_estudiante": create_estudiante().pk,
            "id_representante": create_'representante'().pk,
            "id_nivel": create_nivel().pk,
            "id_secretaria": create_'secretaria'().pk,
        }
        url = reverse('appjardin_preinscripcion_update', args=[preinscripcion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class ProfesorViewTest(unittest.TestCase):
    '''
    Tests for Profesor
    '''
    def setUp(self):
        self.client = Client()

    def test_list_profesor(self):
        url = reverse('appjardin_profesor_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_profesor(self):
        url = reverse('appjardin_profesor_create')
        data = {
            "id_profesor": "id_profesor",
            "titulo_profesor": "titulo_profesor",
            "celular": "celular",
            "estado_civil": "estado_civil",
            "id": create_authuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_profesor(self):
        profesor = create_profesor()
        url = reverse('appjardin_profesor_detail', args=[profesor.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_profesor(self):
        profesor = create_profesor()
        data = {
            "id_profesor": "id_profesor",
            "titulo_profesor": "titulo_profesor",
            "celular": "celular",
            "estado_civil": "estado_civil",
            "id": create_authuser().pk,
        }
        url = reverse('appjardin_profesor_update', args=[profesor.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class RepresentanteViewTest(unittest.TestCase):
    '''
    Tests for Representante
    '''
    def setUp(self):
        self.client = Client()

    def test_list_representante(self):
        url = reverse('appjardin_representante_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_representante(self):
        url = reverse('appjardin_representante_create')
        data = {
            "id_representante": "id_representante",
            "celular": "celular",
            "correo": "correo",
            "id": create_authuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_representante(self):
        representante = create_representante()
        url = reverse('appjardin_representante_detail', args=[representante.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_representante(self):
        representante = create_representante()
        data = {
            "id_representante": "id_representante",
            "celular": "celular",
            "correo": "correo",
            "id": create_authuser().pk,
        }
        url = reverse('appjardin_representante_update', args=[representante.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class RepresentanteestudianteViewTest(unittest.TestCase):
    '''
    Tests for Representanteestudiante
    '''
    def setUp(self):
        self.client = Client()

    def test_list_representanteestudiante(self):
        url = reverse('appjardin_representanteestudiante_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_representanteestudiante(self):
        url = reverse('appjardin_representanteestudiante_create')
        data = {
            "id_representanteestudiante": "id_representanteestudiante",
            "id_estudiante": create_estudiante().pk,
            "id_representante": create_representante().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_representanteestudiante(self):
        representanteestudiante = create_representanteestudiante()
        url = reverse('appjardin_representanteestudiante_detail', args=[representanteestudiante.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_representanteestudiante(self):
        representanteestudiante = create_representanteestudiante()
        data = {
            "id_representanteestudiante": "id_representanteestudiante",
            "id_estudiante": create_estudiante().pk,
            "id_representante": create_representante().pk,
        }
        url = reverse('appjardin_representanteestudiante_update', args=[representanteestudiante.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class RolViewTest(unittest.TestCase):
    '''
    Tests for Rol
    '''
    def setUp(self):
        self.client = Client()

    def test_list_rol(self):
        url = reverse('appjardin_rol_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_rol(self):
        url = reverse('appjardin_rol_create')
        data = {
            "id_rol": "id_rol",
            "estudiante": "estudiante",
            "profesor": "profesor",
            "id": create_authuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_rol(self):
        rol = create_rol()
        url = reverse('appjardin_rol_detail', args=[rol.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_rol(self):
        rol = create_rol()
        data = {
            "id_rol": "id_rol",
            "estudiante": "estudiante",
            "profesor": "profesor",
            "id": create_authuser().pk,
        }
        url = reverse('appjardin_rol_update', args=[rol.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class SecretariaViewTest(unittest.TestCase):
    '''
    Tests for Secretaria
    '''
    def setUp(self):
        self.client = Client()

    def test_list_secretaria(self):
        url = reverse('appjardin_secretaria_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_secretaria(self):
        url = reverse('appjardin_secretaria_create')
        data = {
            "id_secretaria": "id_secretaria",
            "fecha_ingreso": "fecha_ingreso",
            "id": create_authuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_secretaria(self):
        secretaria = create_secretaria()
        url = reverse('appjardin_secretaria_detail', args=[secretaria.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_secretaria(self):
        secretaria = create_secretaria()
        data = {
            "id_secretaria": "id_secretaria",
            "fecha_ingreso": "fecha_ingreso",
            "id": create_authuser().pk,
        }
        url = reverse('appjardin_secretaria_update', args=[secretaria.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


