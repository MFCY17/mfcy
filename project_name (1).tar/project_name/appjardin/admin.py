from django.contrib import admin
from django import forms
from .models import Anolectivo, Estudiante, Matricula, Nivel, Paralelo, Pension, Preinscripcion, Profesor, Representante, Representanteestudiante, Rol, Secretaria

class AnolectivoAdminForm(forms.ModelForm):

    class Meta:
        model = Anolectivo
        fields = '__all__'


class AnolectivoAdmin(admin.ModelAdmin):
    form = AnolectivoAdminForm
    list_display = ['id_anolectivo', 'nombre', 'estado']
    readonly_fields = ['id_anolectivo', 'nombre', 'estado']

admin.site.register(Anolectivo, AnolectivoAdmin)


class EstudianteAdminForm(forms.ModelForm):

    class Meta:
        model = Estudiante
        fields = '__all__'


class EstudianteAdmin(admin.ModelAdmin):
    form = EstudianteAdminForm
    list_display = ['id_estudiante', 'tipo_sangre', 'alergias', 'id_secretaria']
    readonly_fields = ['id_estudiante', 'tipo_sangre', 'alergias', 'id_secretaria']

admin.site.register(Estudiante, EstudianteAdmin)


class MatriculaAdminForm(forms.ModelForm):

    class Meta:
        model = Matricula
        fields = '__all__'


class MatriculaAdmin(admin.ModelAdmin):
    form = MatriculaAdminForm
    list_display = ['id_matricula', 'costo', 'fecha']
    readonly_fields = ['id_matricula', 'costo', 'fecha']

admin.site.register(Matricula, MatriculaAdmin)


class NivelAdminForm(forms.ModelForm):

    class Meta:
        model = Nivel
        fields = '__all__'


class NivelAdmin(admin.ModelAdmin):
    form = NivelAdminForm
    list_display = ['id_nivel', 'nombre']
    readonly_fields = ['id_nivel', 'nombre']

admin.site.register(Nivel, NivelAdmin)


class ParaleloAdminForm(forms.ModelForm):

    class Meta:
        model = Paralelo
        fields = '__all__'


class ParaleloAdmin(admin.ModelAdmin):
    form = ParaleloAdminForm
    list_display = ['id_paralelo']
    readonly_fields = ['id_paralelo']

admin.site.register(Paralelo, ParaleloAdmin)


class PensionAdminForm(forms.ModelForm):

    class Meta:
        model = Pension
        fields = '__all__'


class PensionAdmin(admin.ModelAdmin):
    form = PensionAdminForm
    list_display = ['id_pension', 'costo']
    readonly_fields = ['id_pension', 'costo']

admin.site.register(Pension, PensionAdmin)


class PreinscripcionAdminForm(forms.ModelForm):

    class Meta:
        model = Preinscripcion
        fields = '__all__'


class PreinscripcionAdmin(admin.ModelAdmin):
    form = PreinscripcionAdminForm
    list_display = ['id_preinscripcion', 'fecha']
    readonly_fields = ['id_preinscripcion', 'fecha']

admin.site.register(Preinscripcion, PreinscripcionAdmin)


class ProfesorAdminForm(forms.ModelForm):

    class Meta:
        model = Profesor
        fields = '__all__'


class ProfesorAdmin(admin.ModelAdmin):
    form = ProfesorAdminForm
    list_display = ['id_profesor', 'titulo_profesor', 'celular', 'estado_civil']
    readonly_fields = ['id_profesor', 'titulo_profesor', 'celular', 'estado_civil']

admin.site.register(Profesor, ProfesorAdmin)


class RepresentanteAdminForm(forms.ModelForm):

    class Meta:
        model = Representante
        fields = '__all__'


class RepresentanteAdmin(admin.ModelAdmin):
    form = RepresentanteAdminForm
    list_display = ['id_representante', 'celular', 'correo']
    readonly_fields = ['id_representante', 'celular', 'correo']

admin.site.register(Representante, RepresentanteAdmin)


class RepresentanteestudianteAdminForm(forms.ModelForm):

    class Meta:
        model = Representanteestudiante
        fields = '__all__'


class RepresentanteestudianteAdmin(admin.ModelAdmin):
    form = RepresentanteestudianteAdminForm
    list_display = ['id_representanteestudiante']
    readonly_fields = ['id_representanteestudiante']

admin.site.register(Representanteestudiante, RepresentanteestudianteAdmin)


class RolAdminForm(forms.ModelForm):

    class Meta:
        model = Rol
        fields = '__all__'


class RolAdmin(admin.ModelAdmin):
    form = RolAdminForm
    list_display = ['id_rol', 'estudiante', 'profesor']
    readonly_fields = ['id_rol', 'estudiante', 'profesor']

admin.site.register(Rol, RolAdmin)


class SecretariaAdminForm(forms.ModelForm):

    class Meta:
        model = Secretaria
        fields = '__all__'


class SecretariaAdmin(admin.ModelAdmin):
    form = SecretariaAdminForm
    list_display = ['id_secretaria', 'fecha_ingreso']
    readonly_fields = ['id_secretaria', 'fecha_ingreso']

admin.site.register(Secretaria, SecretariaAdmin)


